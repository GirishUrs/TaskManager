package com.girish.TaskManager;

import javax.persistence.*;
@Entity
@Table(name = "operations")
public class Operation {
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private long id;
		@Column(name = "task")
		private String task;
		@Column(name = "category")
		private String category;

		public Operation() {
		}
		public Operation(String task, String category) {
			this.task = task;
			this.category = category;
		}
		public long getId() {
			return id;
		}
		public String getTask() {
			return task;
		}
		public void setTask(String task) {
			this.task = task;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		@Override
		public String toString() {
			return "Operation [id=" + id + ", task=" + task + ", cat=" + category + "]";
		}
	}
