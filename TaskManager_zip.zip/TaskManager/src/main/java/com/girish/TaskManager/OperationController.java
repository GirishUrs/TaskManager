package com.girish.TaskManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.girish.TaskManager.Operation;
import com.girish.TaskManager.OperationRepository;
@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class OperationController {
	 @Autowired
	  OperationRepository operationRepository;
	  @GetMapping("/operations")
	  public ResponseEntity<List<Operation>> getAllOperations(@RequestParam(required = false) String task) {
	    try {
	    	List<Operation> operations = new ArrayList<Operation>();
	        if (task == null)
	          operationRepository.findAll().forEach(operations::add);
	        else
	          operationRepository.findByTaskContaining(task).forEach(operations::add);
	        if (operations.isEmpty()) {
	          return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	        }
	        return new ResponseEntity<>(operations, HttpStatus.OK);
	      } catch (Exception e) {
	        return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	      }
	    }
	  @GetMapping("/operations/{id}")
	  public ResponseEntity<Operation> getOperationById(@PathVariable("id") long id) {
	    Optional<Operation> operationData = operationRepository.findById(id);
	    if (operationData.isPresent()) {
	      return new ResponseEntity<>(operationData.get(), HttpStatus.OK);
	    } else {
	      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	  }
	  @PostMapping("/operations")
	  public ResponseEntity<Operation> createOperation(@RequestBody Operation operation) {
	    try {
	    	Operation operation1 = operationRepository
	          .save(new Operation(operation.getTask(), operation.getCategory()));
	      return new ResponseEntity<>(operation1, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	    
	@PutMapping("/operations/{id}")
	public ResponseEntity<Operation> updateOperation(@PathVariable("id") long id, @RequestBody Operation operation) {
		Optional<Operation> operationData = operationRepository.findById(id);
		if (operationData.isPresent()) {
			Operation operation1 = operationData.get();
			operation1.setTask(operation.getTask());
			operation1.setCategory(operation.getCategory());
			return new ResponseEntity<>(operationRepository.save(operation1), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	@DeleteMapping("/operations/{id}")
	public ResponseEntity<HttpStatus> deleteOperation(@PathVariable("id") long id) {
		try {
			operationRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@DeleteMapping("/operations")
	  public ResponseEntity<HttpStatus> deleteAllOperation() {
	    try {
	      operationRepository.deleteAll();
	      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    } catch (Exception e) {
	      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	

}
