package com.girish.TaskManager;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.girish.TaskManager.Operation;

public interface OperationRepository extends JpaRepository<Operation, Long> {
	  List<Operation> findByTaskContaining(String task);
	}
